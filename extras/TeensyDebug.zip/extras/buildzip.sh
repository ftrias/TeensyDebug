#!/bin/sh
cd ..
zip -r extras/TeensyDebug.zip license.txt library.properties keywords.txt README.md src examples extras
