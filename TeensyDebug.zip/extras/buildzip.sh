#!/bin/sh
cd ..
zip -r TeensyDebug.zip license.txt library.properties keywords.txt README.md src examples extras
