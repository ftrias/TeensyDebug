#!/bin/sh
d=`dirname $0`
cd $d
python teensy_debug
