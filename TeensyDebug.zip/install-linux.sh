#!/bin/sh
d=`dirname $0`
cd $d
/usr/bin/env python teensy_debug.py $1